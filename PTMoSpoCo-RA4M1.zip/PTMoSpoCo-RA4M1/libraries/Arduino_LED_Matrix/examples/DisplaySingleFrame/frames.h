const uint32_t chip[] = {
	0x1503f811,
	0x3181103,
	0xf8150000
};

const uint32_t danger[] = {
	0x400a015,
	0x1502082,
	0x484047fc
};

const uint32_t happy[] = {
	0x19819,
	0x80000001,
	0x81f8000
};

const uint32_t heart[] = {
	0x3184a444,
	0x44042081,
	0x100a0040
};

/*
const uint32_t fullOn[] = {
	0xffffffff,
	0xffffffff,
	0xffffffff
}
*/
